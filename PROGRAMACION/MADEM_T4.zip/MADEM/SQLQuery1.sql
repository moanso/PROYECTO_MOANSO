SELECT DISTINCT O.DESCRIPCION FROM CATEGORIA C JOIN PRODUCTO P ON C.ID_CATEGORIA=P.ID_CATEGORIA 
JOIN PROVEEDOR O ON P.ID_PROVEEDOR=O.ID_PROVEEDOR WHERE C.DESCRIPCION_CATEGORIA='Limpieza';

select * from CLIENTE
select * from PEDIDO
Select * from  ventas
Select * from CATEGORIA
Select * from PRODUCTO
Select * from PROVEEDOR

CREATE TABLE PEDIDO
(
ID_PEDIDO INT PRIMARY KEY,
CLIENTE VARCHAR(15),
FECHA_DE_EMISION VARCHAR(20),
DESC_PEDIDO VARCHAR(200),
MONTO FLOAT 
)
drop  TABLE PEDIDO
DROP COLUMN ID_CLIENTE;
ALTER COLUMN FECHA_DE_EMISION varchar(20);

SELECT DISTINCT P.NOMBRE_PRODUCTO, P.STOCK_PRODUCTO, P.PRECIO_POR_UNIDAD FROM PRODUCTO P JOIN PROVEEDOR O ON P.ID_PROVEEDOR=O.ID_PROVEEDOR WHERE 
O.DESCRIPCION='Electrosil'

SELECT * FROM PRODUCTO P JOIN CATEGORIA C ON P.ID_CATEGORIA=C.ID_CATEGORIA WHERE C.DESCRIPCION_CATEGORIA=''

Select distinct * from PRODUCTO P join CATEGORIA C on P.ID_CATEGORIA=C.ID_CATEGORIA
where C.DESCRIPCION_CATEGORIA='Limpieza'

Select distinct * from PRODUCTO P join CATEGORIA C on P.ID_CATEGORIA=C.ID_CATEGORIA
where C.DESCRIPCION_CATEGORIA='Repuestos'


SELECT * FROM PRODUCTO P JOIN CATEGORIA C ON P.ID_CATEGORIA=C.ID_CATEGORIA WHERE P.NOMBRE_PRODUCTO='' and C.DESCRIPCION_CATEGORIA=''
drop table numeros
drop table ventas

create table numeros(numero int);

create table ventas(Producto varchar(40), Cantidad int, Ganancia float, Fecha varchar(12));

select * from ventas

UPDATE PRODUCTO SET STOCK_PRODUCTO='100' where NOMBRE_PRODUCTO='NOMBRE1'

create proc sp_modificar_stock(
@nom_produc varchar(40),
@cantidad int)
as
update PRODUCTO
set STOCK_PRODUCTO = (STOCK_PRODUCTO - @cantidad)
where NOMBRE_PRODUCTO=@nom_produc
go

exec sp_modificar_venta 'NOMBRE1', '5'
 

alter proc sp_registrar_venta(
@nom varchar(40),
@cant int,
@ganacia float,
@fecha varchar(12)
)
as 
insert into ventas values(@nom, @cant, @ganacia, @fecha)
go

create proc sp_registrarVenta(
@nom varchar(40),
@cant int,
@ganacia float,
@fecha varchar(12)
)
as 
insert into ventas values(@nom, @cant, @ganacia, @fecha)
go

exec sp_registrarVenta 'NOMBRE2', 20,500,'30-05-2018'

create proc sp_registrarPedido(
@idped int,
@cli varchar(15),
@fechemi varchar(20),
@Desc varchar(200),
@mont float
)
as
insert into PEDIDO Values(@idped, @cli, @fechemi, @Desc, @mont)
go

select * from PEDIDO
select * from PRODUCTO
select * from CLIENTE
insert into PEDIDO values(1,'Peru Plast','02/06/2018','Cosa',1)
Select distinct ID_PEDIDO from PEDIDO where CLIENTE = 'Peru Plast'

Select distinct FECHA_DE_EMISION from PEDIDO WHERE ID_PEDIDO 