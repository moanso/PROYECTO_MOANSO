
package pk_formularios;

import pk_conexion.conexion;
import pk_clases.GenerarCodigo;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.sql.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Vector;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import javax.swing.event.DocumentListener;
import javax.swing.event.UndoableEditListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import java.util.Date;
import javax.swing.text.Element;
import javax.swing.text.Position;
import javax.swing.text.Segment;
import static pk_conexion.conexion.main;
public class Registrar_Pedido extends javax.swing.JFrame {

    String puerto="62076" , pass="relinquished";    
    Connection con=null;
    Vector registros=null;
    CallableStatement cst;
    
    public Registrar_Pedido() {
        initComponents();
        CargarCliente();
        showDate();
       this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txt_IdPedido = new javax.swing.JTextField();
        cbxCliente = new javax.swing.JComboBox<>();
        txtbox_fecha_emision = new javax.swing.JTextField();
        txt_Descripcion = new javax.swing.JTextField();
        txt_Monto = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        btn_Registrar = new javax.swing.JButton();
        btn_Limpiar = new javax.swing.JToggleButton();
        btn_buscar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("REGISTRAR PEDIDO");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("ID Pedido: ");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 30, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Cliente:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 70, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Fecha de emision:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 120, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Descripcion:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 160, -1, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Monto:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 200, -1, -1));

        txt_IdPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_IdPedidoActionPerformed(evt);
            }
        });
        getContentPane().add(txt_IdPedido, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 30, 120, -1));

        cbxCliente.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "--Seleccione--" }));
        cbxCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxClienteActionPerformed(evt);
            }
        });
        getContentPane().add(cbxCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 70, 120, 30));

        txtbox_fecha_emision.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtbox_fecha_emisionActionPerformed(evt);
            }
        });
        getContentPane().add(txtbox_fecha_emision, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 120, 120, -1));
        getContentPane().add(txt_Descripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 160, 120, -1));
        getContentPane().add(txt_Monto, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 200, 72, -1));

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pk_imagenes/descarga.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 310, 50, 40));

        btn_Registrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pk_imagenes/agregar.png"))); // NOI18N
        btn_Registrar.setText("Registrar");
        btn_Registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_RegistrarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Registrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 260, -1, -1));

        btn_Limpiar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pk_imagenes/edit2_icon-icons.com_61199.png"))); // NOI18N
        btn_Limpiar.setText("Limpiar");
        btn_Limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_LimpiarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Limpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 260, -1, -1));

        btn_buscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pk_imagenes/Ayuda.jpg"))); // NOI18N
        btn_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_buscarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 0, 50, 50));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pk_imagenes/RTA1uwq4B9PmpB0_ukWe5zl72eJkfbmt4t8yenImKBVvK0kTmF0xjctABnaLJIm9.jpg"))); // NOI18N
        jLabel2.setText(" ");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 430, 360));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_IdPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_IdPedidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_IdPedidoActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        close();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btn_RegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_RegistrarActionPerformed

       String cliente,descripcion,fecha_emision;
       int id_pedido;
       float monto;
       
       id_pedido = Integer.parseInt(this.txt_IdPedido.getText());
       cliente = this.cbxCliente.getSelectedItem().toString();
       descripcion= this.txt_Descripcion.getText();
       fecha_emision = this.txtbox_fecha_emision.getText();
       monto = Float.parseFloat(this.txt_Monto.getText());
       
       if(descripcion.isEmpty() ||  fecha_emision.isEmpty() || id_pedido==0 || monto==0){
                JOptionPane.showMessageDialog(this, "Datos Invalidos", "Error", JOptionPane.ERROR_MESSAGE); }
       else
       {
       try {
            cst = DriverManager.getConnection("jdbc:sqlserver://localhost:62076;"
            + "database=MADEM;user=sa;password=relinquished;").prepareCall("{call sp_registrarPedido(?,?,?,?,?)}");            
            cst.setInt("idped", id_pedido);
            cst.setString("cli", cliente);
            cst.setString("fechemi", fecha_emision);
            cst.setString("Desc", descripcion);
            cst.setFloat("mont", monto);
            
            
            
            int rpta = cst.executeUpdate();
            if (rpta == 1) {
                JOptionPane.showMessageDialog(this,"*Pedido Nro. "+ id_pedido + " registrado correctamente!!", "Atencion", JOptionPane.INFORMATION_MESSAGE);
            }            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
                
        Administrador entrar = new Administrador();
        entrar.setVisible(true);
       dispose();
       }
    }//GEN-LAST:event_btn_RegistrarActionPerformed

    private void btn_LimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_LimpiarActionPerformed
        // TODO add your handling code here:
        Limpiar();
    }//GEN-LAST:event_btn_LimpiarActionPerformed

    private void txtbox_fecha_emisionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtbox_fecha_emisionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtbox_fecha_emisionActionPerformed

    private void cbxClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxClienteActionPerformed

    private void btn_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buscarActionPerformed
        // TODO add your handling code here:
        JOptionPane.showMessageDialog(null," - Asegurese rellenar todos los campos para hacer uso del boton 'Registrar' "
            + "\n\n - No pueden existir campos vacios"
            + "\n\n - Dudas o sugerencias, contactese al sgte. correo: angeltakeshi20@gmail.com ");
    }//GEN-LAST:event_btn_buscarActionPerformed

    public void showDate()
    { 
        Date d = new Date();
        SimpleDateFormat sf  = new SimpleDateFormat("dd/MM/yyyy");
        txtbox_fecha_emision.setText(sf.format(d));
    }
    private void Limpiar()
    {
        cbxCliente.setSelectedIndex(0);
        this.txt_Descripcion.setText("");
        this.txt_Monto.setText("");
        this.txt_IdPedido.setText("");
    }
    private void close(){
        if (JOptionPane.showConfirmDialog(rootPane, "¿Desea Volver al Inicio?",
                "Cerrar Ventana", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION){
          Login c = new Login();
          c.setVisible(true);
          dispose();
        }
        else
        {
            Administrador A = new Administrador();
          A.setVisible(true);
          dispose();
        }       
    }
    public void CargarCliente(){
        Connection cn=null;
        Vector registros=null;
         try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            cn=DriverManager.getConnection("jdbc:sqlserver://localhost:"+puerto+";databaseName=MADEM;"
               +"user=sa;password="+pass+";");
            Statement stm=cn.createStatement();
            String query2="Select distinct * from CLIENTE; ";
            ResultSet rs=stm.executeQuery(query2);
            registros=new Vector();
            while(rs.next()){
                cbxCliente.addItem(rs.getString("DESCRIPCION_CLIENTE"));
            }
        }catch(SQLException e){
          JOptionPane.showMessageDialog(rootPane, e.getMessage());    
        }catch(ClassNotFoundException e){}

    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Registrar_Pedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Registrar_Pedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Registrar_Pedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Registrar_Pedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Registrar_Pedido().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton btn_Limpiar;
    private javax.swing.JButton btn_Registrar;
    private javax.swing.JButton btn_buscar;
    private javax.swing.JComboBox<String> cbxCliente;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JTextField txt_Descripcion;
    private javax.swing.JTextField txt_IdPedido;
    private javax.swing.JTextField txt_Monto;
    private javax.swing.JTextField txtbox_fecha_emision;
    // End of variables declaration//GEN-END:variables
}
