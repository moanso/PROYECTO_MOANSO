
package pk_formularios;
import pk_conexion.conexion;
import javax.swing.JOptionPane;

public class Administrador extends javax.swing.JFrame {

    public Administrador() {
        initComponents();
        
        this.setSize(500,500);
        this.setLocationRelativeTo(null);
    }

    Administrador(String string, String alberto, String sarmiento, String string0, int i, int i0) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnRegistrarProducto = new javax.swing.JButton();
        btnModificarProducto = new javax.swing.JButton();
        btnRegistrarCliente = new javax.swing.JButton();
        btnRegistrarPedido = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        btnConsultarProducto = new javax.swing.JButton();
        btnConsultarInventario = new javax.swing.JButton();
        btnCobrarProducto = new javax.swing.JButton();
        btnEnviarProducto = new javax.swing.JButton();
        btnRegistroVentas = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("MADEM");
        setMinimumSize(new java.awt.Dimension(260, 330));
        setResizable(false);
        getContentPane().setLayout(null);

        btnRegistrarProducto.setBackground(new java.awt.Color(153, 153, 153));
        btnRegistrarProducto.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnRegistrarProducto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pk_imagenes/8761.png"))); // NOI18N
        btnRegistrarProducto.setText("Registrar Producto");
        btnRegistrarProducto.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegistrarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistrarProductoActionPerformed(evt);
            }
        });
        getContentPane().add(btnRegistrarProducto);
        btnRegistrarProducto.setBounds(30, 30, 210, 50);

        btnModificarProducto.setBackground(new java.awt.Color(153, 153, 153));
        btnModificarProducto.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnModificarProducto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pk_imagenes/edit2_icon-icons.com_61199.png"))); // NOI18N
        btnModificarProducto.setText("Modificar Producto");
        btnModificarProducto.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnModificarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarProductoActionPerformed(evt);
            }
        });
        getContentPane().add(btnModificarProducto);
        btnModificarProducto.setBounds(30, 100, 210, 50);

        btnRegistrarCliente.setBackground(new java.awt.Color(153, 153, 153));
        btnRegistrarCliente.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnRegistrarCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pk_imagenes/agregar.png"))); // NOI18N
        btnRegistrarCliente.setText("Regitrar Cliente");
        btnRegistrarCliente.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegistrarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistrarClienteActionPerformed(evt);
            }
        });
        getContentPane().add(btnRegistrarCliente);
        btnRegistrarCliente.setBounds(260, 30, 210, 50);

        btnRegistrarPedido.setBackground(new java.awt.Color(153, 153, 153));
        btnRegistrarPedido.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnRegistrarPedido.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pk_imagenes/8761.png"))); // NOI18N
        btnRegistrarPedido.setText("Registrar Pedido");
        btnRegistrarPedido.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegistrarPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistrarPedidoActionPerformed(evt);
            }
        });
        getContentPane().add(btnRegistrarPedido);
        btnRegistrarPedido.setBounds(260, 100, 210, 50);

        btnSalir.setBackground(new java.awt.Color(153, 153, 153));
        btnSalir.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pk_imagenes/descarga.png"))); // NOI18N
        btnSalir.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });
        getContentPane().add(btnSalir);
        btnSalir.setBounds(210, 410, 70, 40);

        btnConsultarProducto.setBackground(new java.awt.Color(153, 153, 153));
        btnConsultarProducto.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnConsultarProducto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pk_imagenes/list-on-a-notebook-stroke-symbol_icon-icons.com_57808.png"))); // NOI18N
        btnConsultarProducto.setText("Consultar Producto");
        btnConsultarProducto.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnConsultarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarProductoActionPerformed(evt);
            }
        });
        getContentPane().add(btnConsultarProducto);
        btnConsultarProducto.setBounds(30, 240, 210, 50);

        btnConsultarInventario.setBackground(new java.awt.Color(153, 153, 153));
        btnConsultarInventario.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnConsultarInventario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pk_imagenes/list-on-a-notebook-stroke-symbol_icon-icons.com_57808.png"))); // NOI18N
        btnConsultarInventario.setText("Consultar Inventario");
        btnConsultarInventario.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnConsultarInventario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarInventarioActionPerformed(evt);
            }
        });
        getContentPane().add(btnConsultarInventario);
        btnConsultarInventario.setBounds(260, 170, 210, 50);

        btnCobrarProducto.setBackground(new java.awt.Color(153, 153, 153));
        btnCobrarProducto.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnCobrarProducto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pk_imagenes/carrito-de-compras.png"))); // NOI18N
        btnCobrarProducto.setText("Cobrar Productos");
        btnCobrarProducto.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnCobrarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCobrarProductoActionPerformed(evt);
            }
        });
        getContentPane().add(btnCobrarProducto);
        btnCobrarProducto.setBounds(30, 170, 210, 50);

        btnEnviarProducto.setBackground(new java.awt.Color(153, 153, 153));
        btnEnviarProducto.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnEnviarProducto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pk_imagenes/comprado.png"))); // NOI18N
        btnEnviarProducto.setText("Enviar Producto");
        btnEnviarProducto.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnEnviarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnviarProductoActionPerformed(evt);
            }
        });
        getContentPane().add(btnEnviarProducto);
        btnEnviarProducto.setBounds(30, 310, 210, 50);

        btnRegistroVentas.setBackground(new java.awt.Color(153, 153, 153));
        btnRegistroVentas.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnRegistroVentas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pk_imagenes/list-on-a-notebook-stroke-symbol_icon-icons.com_57808.png"))); // NOI18N
        btnRegistroVentas.setText("Registro de Ventas");
        btnRegistroVentas.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegistroVentas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistroVentasActionPerformed(evt);
            }
        });
        getContentPane().add(btnRegistroVentas);
        btnRegistroVentas.setBounds(260, 240, 210, 50);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pk_imagenes/fondo-de-herramientas-en-diseno-plano_23-2147616437.jpg"))); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 500, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRegistrarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarProductoActionPerformed
        Registrar_Producto entrar = new Registrar_Producto();
        entrar.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnRegistrarProductoActionPerformed

    private void btnModificarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarProductoActionPerformed
        Modificar_Producto entrar = new Modificar_Producto();
        entrar.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnModificarProductoActionPerformed

    private void btnRegistrarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarClienteActionPerformed
        Registrar_Cliente entrar = new Registrar_Cliente();
        entrar.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnRegistrarClienteActionPerformed

    private void btnRegistrarPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarPedidoActionPerformed
        Registrar_Pedido entrar = new Registrar_Pedido();
        entrar.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnRegistrarPedidoActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        close();
        
    }//GEN-LAST:event_btnSalirActionPerformed

    private void btnConsultarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarProductoActionPerformed
        // TODO add your handling code here:
        Consultar_Producto entrar = new Consultar_Producto();
        entrar.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnConsultarProductoActionPerformed

    private void btnConsultarInventarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarInventarioActionPerformed
        // TODO add your handling code here:
        Consultar_Inventario entrar = new Consultar_Inventario();
        entrar.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnConsultarInventarioActionPerformed

    private void btnCobrarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCobrarProductoActionPerformed
        // TODO add your handling code here:
        Cobrar_Producto entrar = new Cobrar_Producto();
        entrar.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnCobrarProductoActionPerformed

    private void btnEnviarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnviarProductoActionPerformed
        // TODO add your handling code here:
        EnviarProducto entrar = new EnviarProducto();
        entrar.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnEnviarProductoActionPerformed

    private void btnRegistroVentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistroVentasActionPerformed
        // TODO add your handling code here:
        Mostrar_RegistroVentas entrar = new Mostrar_RegistroVentas();
        entrar.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnRegistroVentasActionPerformed

    private void close(){
        
          Login c = new Login();
          c.setVisible(true);
          dispose();
        
    } 

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Administrador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Administrador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Administrador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Administrador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Administrador().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCobrarProducto;
    private javax.swing.JButton btnConsultarInventario;
    private javax.swing.JButton btnConsultarProducto;
    private javax.swing.JButton btnEnviarProducto;
    private javax.swing.JButton btnModificarProducto;
    private javax.swing.JButton btnRegistrarCliente;
    private javax.swing.JButton btnRegistrarPedido;
    private javax.swing.JButton btnRegistrarProducto;
    private javax.swing.JButton btnRegistroVentas;
    private javax.swing.JButton btnSalir;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
