package pk_formularios;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import pk_conexion.conexion;
import java.sql.*;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;


public class Consultar_Producto extends javax.swing.JFrame {
    String puerto="62076" , pass="relinquished";   
    private TableRowSorter trsFiltro;
    public Consultar_Producto() {
        initComponents();
        CargarCategoria();
        this.setSize(796,550);
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblLista = new javax.swing.JTable();
        cbxCategoria = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        comboFiltro = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        txtFiltro = new javax.swing.JTextField();
        btn_ayuda = new javax.swing.JToggleButton();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("CONSULTAR PRODUCTO");
        setMinimumSize(new java.awt.Dimension(510, 535));
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Categoria:");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(50, 20, 120, 20);

        tblLista.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tblLista);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(40, 120, 710, 330);

        cbxCategoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "--Seleccionar--" }));
        cbxCategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxCategoriaActionPerformed(evt);
            }
        });
        getContentPane().add(cbxCategoria);
        cbxCategoria.setBounds(150, 20, 140, 30);

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pk_imagenes/descarga.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(680, 460, 70, 40);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Filtrar por:");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(50, 70, 150, 20);

        comboFiltro.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "--Seleccionar--", "Codigo", "Nombre", "Precio por unidad", "Stock", "Proveedor", "Precio Total", " " }));
        getContentPane().add(comboFiltro);
        comboFiltro.setBounds(150, 70, 140, 30);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Buscar:");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(330, 70, 60, 20);

        txtFiltro.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtFiltroKeyReleased(evt);
            }
        });
        getContentPane().add(txtFiltro);
        txtFiltro.setBounds(400, 70, 140, 30);

        btn_ayuda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pk_imagenes/Ayuda.jpg"))); // NOI18N
        btn_ayuda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ayudaActionPerformed(evt);
            }
        });
        getContentPane().add(btn_ayuda);
        btn_ayuda.setBounds(730, 0, 50, 50);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pk_imagenes/RTA1uwq4B9PmpB0_ukWe5zl72eJkfbmt4t8yenImKBVvK0kTmF0xjctABnaLJIm9.jpg"))); // NOI18N
        getContentPane().add(jLabel4);
        jLabel4.setBounds(-10, -10, 800, 530);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cbxCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxCategoriaActionPerformed
//        listarCategoria();
//        CargarStock();
        Llenar();
    }//GEN-LAST:event_cbxCategoriaActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        close();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtFiltroKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtFiltroKeyReleased
        // TODO add your handling code here:
        txtFiltro.addKeyListener(new KeyAdapter() {
            public void keyReleased(final KeyEvent e) {
                String cadena = (txtFiltro.getText());
                txtFiltro.setText(cadena);
                repaint();
                filtro();
            }
        });
        trsFiltro = new TableRowSorter(tblLista.getModel());
        tblLista.setRowSorter(trsFiltro);
    }//GEN-LAST:event_txtFiltroKeyReleased

    private void btn_ayudaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ayudaActionPerformed
        // TODO add your handling code here:
        JOptionPane.showMessageDialog(null," - Seleccione una categoria para visualizar los productos "
                + "\n\n - Asegurese escribir una dato tras seleccionar una opcion de filtrado \n\n - Para ordenar los datos de una columna realize un click izq. sobre el nombre de esta"
                + "\n\n - Dudas o sugerencias, contactese al sgte. correo: angeltakeshi20@gmail.com ");
    }//GEN-LAST:event_btn_ayudaActionPerformed

    public void filtro() {
        int columnaABuscar = 0;
        if (comboFiltro.getSelectedItem() == "Codigo") {
            columnaABuscar = 0;
        }
        if (comboFiltro.getSelectedItem().toString() == "Nombre") {
            columnaABuscar = 1;
        }
        if (comboFiltro.getSelectedItem() == "Precio por unidad") {
            columnaABuscar = 2;
        }
        if (comboFiltro.getSelectedItem() == "Stock") {
            columnaABuscar = 3;
        }
        if (comboFiltro.getSelectedItem() == "Proveedor") {
            columnaABuscar = 4;
        }
        if (comboFiltro.getSelectedItem() == "Precio Total") {
            columnaABuscar = 5;
        }
        trsFiltro.setRowFilter(RowFilter.regexFilter(txtFiltro.getText(), columnaABuscar));
    }

    private void close(){
        if (JOptionPane.showConfirmDialog(rootPane, "¿Desea Volver al Inicio?",
                "Cerrar Ventana", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION){
          Login c = new Login();
          c.setVisible(true);
          dispose();
        }
        else
        {
            Administrador A = new Administrador();
          A.setVisible(true);
          dispose();
        }
    }    
    public void CargarCategoria(){
        Connection cn=null;
        Vector registros=null;
         try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            cn=DriverManager.getConnection("jdbc:sqlserver://localhost:"+puerto+";databaseName=MADEM;"
               +"user=sa;password="+pass+";");
            Statement stm=cn.createStatement();
            String query2="Select distinct * from CATEGORIA; ";
            ResultSet rs=stm.executeQuery(query2);
            registros=new Vector();
            while(rs.next()){
                cbxCategoria.addItem(rs.getString("DESCRIPCION_CATEGORIA"));                
            }
        }catch(SQLException e){
          JOptionPane.showMessageDialog(rootPane, e.getMessage());    
        }catch(ClassNotFoundException e){}

    }
    
//public void CargarStock(){
//        cbxStock.removeAllItems();
//        Connection cn=null;
//        Vector registros=null;
//         try{
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            cn=DriverManager.getConnection("jdbc:sqlserver://localhost:"+puerto+";databaseName=MADEM;"
//               +"user=sa;password="+pass+";");
//            Statement stm=cn.createStatement();
//            String query2="Select distinct * from CATEGORIA C join PRODUCTO P"
//                    + " on(C.ID_CATEGORIA=P.ID_CATEGORIA) where C.DESCRIPCION_CATEGORIA ='"+cbxCategoria.getSelectedItem()+"'";
//            ResultSet rs=stm.executeQuery(query2);
//            registros=new Vector();
//            while(rs.next()){
//                cbxStock.addItem(rs.getInt("STOCK_PRODUCTO"));
//            }
//        }catch(SQLException e){
//          JOptionPane.showMessageDialog(rootPane, e.getMessage());    
//        }catch(ClassNotFoundException e){}
//
//    }
    private Vector listar() {
        Connection cn=null;
        Vector reg=null;
         try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            cn=DriverManager.getConnection("jdbc:sqlserver://localhost:"+puerto+";databaseName=MADEM;"
               +"user=sa;password="+pass+";");
            Statement stm=cn.createStatement();
//         ResultSet rs = stm.executeQuery("SELECT * FROM CATEGORIA C join PRODUCTO P"
//                 + " ON C.ID_CATEGORIA=P.ID_CATEGORIA and DESCRIPCION_CATEGORIA='"+cbxCategoria.getSelectedItem()+"';");

ResultSet rs = stm.executeQuery("SELECT * FROM CATEGORIA C join PRODUCTO P ON C.ID_CATEGORIA=P.ID_CATEGORIA JOIN PROVEEDOR R ON R.ID_PROVEEDOR=P.ID_PROVEEDOR and DESCRIPCION_CATEGORIA='"+cbxCategoria.getSelectedItem()+"';");
         reg = new Vector();

             while(rs.next()){
             Vector item = new Vector();
             item.add(rs.getInt("ID_PRODUCTO"));
             item.add(rs.getString("NOMBRE_PRODUCTO"));
             item.add(rs.getFloat("PRECIO_POR_UNIDAD"));
             item.add(rs.getInt("STOCK_PRODUCTO"));
             item.add(rs.getString("DESCRIPCION"));
             item.add(rs.getInt("PRECIO_TOTAL"));
             reg.add(item);
             }
         }
         catch(Exception e){
         System.out.print(e);
         }
         return reg;
    }
    
//    private Vector listarCategoria() {
//         Connection con=null;
//         Statement stm=null;
//         Vector reg=null;
//         try{
//         con = conexion.getConexion();
//         stm=con.createStatement();
//         ResultSet rs = stm.executeQuery("SELECT * FROM CATEGORIA C join PRODUCTO P"
//                 + " ON C.ID_CATEGORIA=P.ID_CATEGORIA; ");
//         reg = new Vector();
//
//             while(rs.next()){
//             Vector item = new Vector();
//             item.add(rs.getInt("cod_pro"));
//             item.add(rs.getString("nom_prod"));
//             item.add(rs.getString("des_prov"));
//             item.add(rs.getFloat("precio_total"));
//             item.add(rs.getFloat("precio_pro_uni"));
//             item.add(rs.getInt("stock_pro"));
//             item.add(rs.getString("fec_ingre"));
//             item.add(rs.getString("des_cat"));
//             reg.add(item);
//             }
//         }
//         catch(Exception e){
//         System.out.print(e);
//         }
//         return reg;
//    }

    private void Llenar() {
        Vector colu = new Vector();
        colu.addElement("ID PRODUCTO");
        colu.addElement("NOMBRE PRODUCTO");
        colu.addElement("PRECIO X UNIDAD");
        colu.addElement("STOCK");
        colu.addElement("PROVEEDOR");
        colu.addElement("PRECIO TOTAL");
        Vector reg = new Vector();
        reg = listar();
        DefaultTableModel dtm = new DefaultTableModel(reg, colu);
        this.tblLista.setModel(dtm);
        
        trsFiltro=new TableRowSorter<>(dtm);
        tblLista.setRowSorter(trsFiltro);
        
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Consultar_Producto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Consultar_Producto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Consultar_Producto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Consultar_Producto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Consultar_Producto().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton btn_ayuda;
    private javax.swing.JComboBox<String> cbxCategoria;
    private javax.swing.JComboBox<String> comboFiltro;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblLista;
    private javax.swing.JTextField txtFiltro;
    // End of variables declaration//GEN-END:variables
}
