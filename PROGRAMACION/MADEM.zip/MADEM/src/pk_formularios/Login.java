/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk_formularios;

import javax.swing.JOptionPane;
import pk_conexion.conexion;
import pk_clases.*;


public class Login extends javax.swing.JFrame {

    public Login() {
        initComponents();
        this.setLocationRelativeTo(null);
        setTitle("MADEM");
        setSize(580,360);
        this.getContentPane().setBackground(java.awt.Color.white);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        rbtAdmin = new javax.swing.JRadioButton();
        lbl_admi = new javax.swing.JLabel();
        lbl_logo = new javax.swing.JLabel();
        lbl_nombre = new javax.swing.JLabel();
        btn_salir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setMinimumSize(new java.awt.Dimension(480, 260));
        setResizable(false);
        getContentPane().setLayout(null);

        rbtAdmin.setBackground(new java.awt.Color(51, 153, 255));
        buttonGroup1.add(rbtAdmin);
        rbtAdmin.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        rbtAdmin.setText("Administrador");
        rbtAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtAdminActionPerformed(evt);
            }
        });
        getContentPane().add(rbtAdmin);
        rbtAdmin.setBounds(390, 120, 130, 50);

        lbl_admi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pk_imagenes/administrador.jpg"))); // NOI18N
        getContentPane().add(lbl_admi);
        lbl_admi.setBounds(340, 120, 160, 50);

        lbl_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pk_imagenes/Herramientas-de-Estudio-para-Universitarios.png"))); // NOI18N
        getContentPane().add(lbl_logo);
        lbl_logo.setBounds(-70, 0, 420, 320);

        lbl_nombre.setFont(new java.awt.Font("Times New Roman", 3, 48)); // NOI18N
        lbl_nombre.setForeground(new java.awt.Color(0, 153, 153));
        lbl_nombre.setText("MADEM");
        getContentPane().add(lbl_nombre);
        lbl_nombre.setBounds(340, 30, 190, 50);

        btn_salir.setBackground(new java.awt.Color(0, 153, 153));
        btn_salir.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        btn_salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pk_imagenes/descarga.png"))); // NOI18N
        btn_salir.setText("SALIR");
        btn_salir.setBorder(javax.swing.BorderFactory.createEmptyBorder(2, 2, 2, 2));
        btn_salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_salirActionPerformed(evt);
            }
        });
        getContentPane().add(btn_salir);
        btn_salir.setBounds(360, 210, 160, 60);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void rbtAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtAdminActionPerformed
        // TODO add your handling code here:
        String user = JOptionPane.showInputDialog(null, "ID");
        String password = JOptionPane.showInputDialog(null, "Password");
        
        if("admin".equals(user) && "1234".equals(password)){
            Administrador entrar = new Administrador();
            entrar.setVisible(true);
            dispose();
        } else {
            JOptionPane.showMessageDialog(null,"Vuelva a Intentarlo");
        }
    }//GEN-LAST:event_rbtAdminActionPerformed

    private void btn_salirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_salirActionPerformed
        this.dispose();;
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_salirActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_salir;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JLabel lbl_admi;
    private javax.swing.JLabel lbl_logo;
    private javax.swing.JLabel lbl_nombre;
    private javax.swing.JRadioButton rbtAdmin;
    // End of variables declaration//GEN-END:variables
}
